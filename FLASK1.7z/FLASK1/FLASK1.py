from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# Генерация 1000 уникальных телефонных номеров
phone_numbers = [f"89138256{i:03d}" for i in range(1000)]

@app.route('/')
def index():
    return render_template('index.html', numbers=phone_numbers)

@app.route('/search', methods=['POST'])
def search():
    phone = request.form.get('phone', '').strip()
    return redirect(url_for('number_details', phone=phone))

@app.route('/number/<phone>')
def number_details(phone):
    return render_template('details.html', number=phone)

if __name__ == '__main__':
    app.run(debug=True, port=5005)